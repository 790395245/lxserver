module.exports = {
  upgrade: true,
  reject: [
    'chalk',
    '@types/ws',
  ],
}
