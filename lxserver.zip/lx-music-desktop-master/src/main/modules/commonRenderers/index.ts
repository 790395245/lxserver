import common from './common'
import list from './list'
import dislike from './dislike'

export default () => {
  common()
  list()
  dislike()
}
