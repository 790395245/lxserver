import log from 'electron-log/node'

log.transports.file.level = 'info'
// log.initialize()
