

// // declare module NodeJS {
// //   interface Global {
// //     isDev: boolean
// //     envParams: LX.EnvParams
// //     staticPath: string
// //     lx: Lx
// //   }
// // }

declare const webpackStaticPath: string
declare const webpackUserApiPath: string

