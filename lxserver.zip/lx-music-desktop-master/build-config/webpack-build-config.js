module.exports = {
  minimize: true,
}
